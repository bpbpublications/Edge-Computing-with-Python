import serial

comPort = serial.Serial(port = "COM4", baudrate=9600, timeout = 1)
comPort.close()
comPort.open()
runloop = True
while (runloop):
    if comPort.is_open:
        datarcv = comPort.read(8)
        decoded_data = datarcv.decode()
        data = decoded_data.strip().removesuffix('\r\r\\n')
        if data == '':
            continue
        sensorvalue = int(data)
        print(sensorvalue)
        if sensorvalue == 11:
            print('Closing communication')
            comPort.close()
            runloop = False
            break