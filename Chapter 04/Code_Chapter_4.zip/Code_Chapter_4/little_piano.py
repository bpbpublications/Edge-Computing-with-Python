import keyboard
import winsound
import time

def A_key_press_callback(e):
    winsound.Beep(250, 400)
    time.sleep(1/5)
    return

def S_key_press_callback(e):
    winsound.Beep(300, 400)
    time.sleep(1/5)
    return

def D_key_press_callback(e):
    winsound.Beep(450, 400)
    time.sleep(1/5)
    return

def F_key_press_callback(e):
    winsound.Beep(500, 400)
    time.sleep(1/5)
    return

def G_key_press_callback(e):
    winsound.Beep(550, 400)
    time.sleep(1/5)
    return

def H_key_press_callback(e):
    winsound.Beep(600, 400)
    time.sleep(1/5)
    return

def J_key_press_callback(e):
    winsound.Beep(650, 400)
    time.sleep(1/5)
    return

keyboard.on_press_key('A', A_key_press_callback)
keyboard.on_press_key('S', S_key_press_callback)
keyboard.on_press_key('D', D_key_press_callback)
keyboard.on_press_key('F', F_key_press_callback)
keyboard.on_press_key('G', G_key_press_callback)
keyboard.on_press_key('H', H_key_press_callback)
keyboard.on_press_key('J', J_key_press_callback)
keyboard.wait('esc')