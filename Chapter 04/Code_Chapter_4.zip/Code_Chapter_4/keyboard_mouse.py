import keyboard
import mouse
import time

def mouse_click_callback():
    keyboard.send("caps lock")
    time.sleep(1)
    return
mouse.on_click(mouse_click_callback, args=())
keyboard.wait('esc')