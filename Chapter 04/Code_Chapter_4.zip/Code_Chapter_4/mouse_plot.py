import mouse
import matplotlib.pyplot as plt
import matplotlib.animation as animation

data = []

fig = plt.figure()
plt.xlabel('Time')
plt.ylabel('X and Y')
plt.title('Mouse Movement Trend')

def animate(i):
    mouse_pos = mouse.get_position()
    data.append(mouse_pos)
    plt.plot(data)

ani = animation.FuncAnimation(fig, animate, interval=1000)
plt.show()