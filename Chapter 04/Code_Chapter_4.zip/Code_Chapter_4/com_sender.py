import serial
import keyboard

keylist = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q',
'r','s','t','u','v','w','x','y','z', 'delete']
com3port = serial.Serial(port = "COM3", baudrate=9600, timeout = 1)
com3port.close()
com3port.open()

def keypress_callback(event):
    if not com3port.is_open:
        print('Port not open')
        return

    keyname = str(event.name)
    if keylist.__contains__(keyname.lower()):
        print('Sending -> ', keyname)
        datasend = bytes(keyname, 'utf-8')
        com3port.write(datasend)

keyboard.on_press(keypress_callback, suppress=False)
keyboard.wait('esc')
com3port.close()