import serial.tools.list_ports as portlist

for com_port_obj in portlist.comports():
    print(com_port_obj.device)