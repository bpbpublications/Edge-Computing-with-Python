import serial

com4 = serial.Serial(port = "COM4", baudrate=9600, timeout = 2)
com4.close()
com4.open()
runloop = True
while (runloop):
    if com4.is_open:
        datarcv = com4.read(8)
        data = datarcv.decode('utf-8')
        if data == '':
            continue
        print('Data Received ->', data)
        if data.__contains('del'):
            print('Closing communication')
            com4.close()
            runloop = False
            break