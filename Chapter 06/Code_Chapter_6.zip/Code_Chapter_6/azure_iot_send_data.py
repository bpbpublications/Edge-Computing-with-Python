import random
import time
from azure.iot.device import IoTHubDeviceClient, Message

CONNECTION_STRING = "HostName=Edge-Python.azure-devices.net;DeviceId=My-PC;SharedAccessKey=xxxxxxxxxxxxxxxxxxXXXXXXXXXXXXXxxxxxxx"

def create_iot_hub_client():
    model_id = "dtmi:com:example:NonExistingController;1"
    client = IoTHubDeviceClient.create_from_connection_string(
            CONNECTION_STRING, product_info=model_id, websockets=True)
    try:
        client.connect()
    except:
        client.shutdown()
        raise
    return client

def send_data(client):
    client.connect()
    while True:
        message = Message(f'{{"temperature": {random.randint(20, 50)}, \
                            "humidity": {random.randint(50, 100)}}}')
        print(f"Sending message: {message}")
        client.send_message(message)
        print("Message sent")
        time.sleep(2)

def main():
    client = create_iot_hub_client()
    try:
        send_data(client)
    except KeyboardInterrupt:
        print("IoTHubClient sample stopped by user")
    finally:
        print("Shutting down IoTHubClient")
        client.shutdown()

if __name__ == '__main__':
    main()