import time
import socket
import sys

timestart = time.perf_counter()
HOST = '<IP-Address>'
PORT = 9009
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

def send_packet(msg):
    sock.sendall(msg.encode())

try:
    sock.connect((HOST, PORT))
    for i in range(100):
        time_stamp = time.time_ns()
        send_packet(f'machine,name=temperature_sensor value={i} {time_stamp}\n')
        send_packet(f'machine,name=pressure_sensor value={i} {time_stamp}\n')
        send_packet(f'machine,name=speed_sensor value={i} {time_stamp}\n')

except socket.error as e:
    sys.stderr.write(f'Got error: {e}')

sock.close()
elapsed = time.perf_counter() - timestart
print(f"{__file__} executed in {elapsed:0.9f} seconds.")