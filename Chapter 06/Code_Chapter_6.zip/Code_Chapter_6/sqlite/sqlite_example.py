import sqlite3

conn = sqlite3.connect('my_database.db')
print("Opened database successfully")

conn.execute("CREATE TABLE IF NOT EXISTS Person \
   (NAME TEXT, AGE INT, SALARY REAL)")
print("Table opened successfully")

conn.execute("INSERT INTO Person (NAME, AGE, SALARY) \
   VALUES ('Harry', 32, 20000.00 )")
conn.execute("INSERT INTO Person (NAME, AGE, SALARY) \
   VALUES ('Marry', 42, 20500.50 )")
print("Insert done successfully")

cursor = conn.execute("SELECT name, age, salary from Person")
for row in cursor:
   print(f"NAME = {row[0]}\t AGE = {row[1]}\t SALARY = {row[2]}")

conn.execute("UPDATE Person set SALARY = 25000.00 where NAME = 'Marry'")
conn.commit()
print(f"Update done successfully")

cursor = conn.execute("SELECT name, age, salary from Person \
   where NAME = 'Marry'")
for row in cursor:
   print(f"NAME = {row[0]}\t AGE = {row[1]}\t SALARY = {row[2]}")

conn.execute("DELETE from Person where NAME = 'Harry'")
conn.commit()
print(f"Delete done successfully")

cursor = conn.execute("SELECT name, age, salary from Person")
for row in cursor:
   print(f"NAME = {row[0]}\t AGE = {row[1]}\t SALARY = {row[2]}")

conn.close()
