import mouse
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import sqlite3
import threading
import time

conn = sqlite3.connect('mouse_map.db', check_same_thread=False)
conn.execute("CREATE TABLE IF NOT EXISTS Mouse_Map (X INT, Y INT)")

fig = plt.figure()
plt.xlabel('Time')
plt.ylabel('X and Y')
plt.title('Mouse Movement Trend')

def insert_into_db(sq_conn: sqlite3.Connection):
    while True:
        mouse_pos = mouse.get_position()
        sql_statement = (f"INSERT INTO Mouse_Map (X, Y) VALUES \
        ({mouse_pos[0]}, {mouse_pos[1]})")
        sq_conn.execute(sql_statement)
        time.sleep(1)

def animate(i):
    cursor = conn.execute("SELECT * FROM Mouse_Map")
    data = cursor.fetchall()
    plt.plot(data)

db_insert_thread = threading.Thread(target=insert_into_db, args=(conn, ))
db_insert_thread.start()
ani = animation.FuncAnimation(fig, animate, interval=1000)
plt.show()
conn.commit()
conn.close()