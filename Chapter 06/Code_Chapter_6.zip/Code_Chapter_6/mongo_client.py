from bson import ObjectId
import pymongo

mongo_client = pymongo.MongoClient("mongodb://<IP-Address>:27017/")
mongo_db = mongo_client["mydatabase"]
mongo_table = mongo_db["persons"]

def display_all(message:str):
   print("Displaying all records -> " + message)
   for record in mongo_table.find():
      print(record)
   return

def add_new_record(name:str, age:int, salary:float):
   print("Add new record")
   record_to_add = {"NAME": name, "AGE": age, "SALARY": salary}
   response = mongo_table.insert_one(record_to_add)
   return response.inserted_id

def update_record(id:ObjectId, field:str, value):
   print("Update the record")
   myquery = { "_id": id }
   newvalues = { "$set": { field: value } }
   response = mongo_table.update_one(myquery, newvalues)
   return

def delete_record(id:ObjectId):
   print("Delete the record")
   record_to_delete = {"_id": id}
   response = mongo_table.delete_one(record_to_delete)
   return

if __name__ == "__main__":
   display_all("Initial position")
   record_id = add_new_record("Harry", 30, 20000)
   update_record(record_id, "SALARY", 20500)
   display_all("After update the record")
   delete_record(record_id)