import argparse
import json
import sys
from urllib import request, error

BASE_API_URL = ""
APIKEY = ""
UNITS = ""

def init_config():
    global BASE_API_URL
    global APIKEY
    global UNITS
    
    file_object = open("config.ini", "r")
    file_content = file_object.readline()
    BASE_API_URL = (line_content.split('#')[1]).removesuffix('\n').strip()
    line_content = file_object.readline()
    APIKEY = (line_content.split('#')[1]).removesuffix('\n').strip()
    line_content = file_object.readline()
    UNITS = (line_content.split('#')[1]).removesuffix('\n').strip()
    file_object.close()    
    return

def read_args():
    parser = argparse.ArgumentParser(
        description="See the temperature and weather of a city"
    )
    parser.add_argument(
        "city", type=str, help="input the name of city"
    )
    return parser.parse_args()

def make_api_url(city_name):
    api_key = APIKEY
    return (f"{BASE_API_URL}?q={city_name}&units={UNITS}&appid={api_key}")

def acquire_weather_data(query_api_url):
    try:
        api_response = request.urlopen(query_api_url)
    except error.HTTPError as http_error:
        sys.exit(f"Error: {http_error.info}")

    weather_data = api_response.read()

    try:
        return json.loads(weather_data)
    except json.JSONDecodeError:
        sys.exit(",Unrecognized server response.")

def proces_and_output_weather_info(weather_data):
    city_name = weather_data["name"]
    weather_description = weather_data["weather"][0]["description"]
    temperature = weather_data["main"]["temp"]
    pressure = weather_data["main"]["pressure"]
    humidity = weather_data["main"]["humidity"]
    print(f"{city_name.capitalize()}\t"
            f"{weather_description.capitalize()}\t({temperature})°C\t"
            f"Pressure={pressure}\tHumidity={humidity}")

if __name__ == "__main__":
    init_config()
    args = read_args()
    api_query_url = make_api_url(args.city)
    weather_data = acquire_weather_data(api_query_url)
    proces_and_output_weather_info(weather_data)
