import psycopg2

connection = None
cursor = None
connection = psycopg2.connect(user='admin', password='quest', database='qdb',
                                host='<IP-Address>', port='8812')
cursor = connection.cursor()
sql_query = 'SELECT * FROM machine;'
cursor.execute(sql_query)
print('Records from machine table')
machine_records = cursor.fetchall()
for record in machine_records:
    print(f"Name={record[0]}, Value={record[1]}, Timestamp={record[2]}")
cursor.close()
connection.close()