# read the file first time
file_object = open("mytextfile.txt", "r")
original_content = file_object.read()
print(original_content)
file_object.close()

# append some content
file_object = open("mytextfile.txt", "a")
file_object.write("This line appended at the end")
file_object.close()

# check after append
file_object = open("mytextfile.txt", "r")
print(file_object.read())
file_object.close()

# write some content
file_object = open("mytextfile.txt", "w")
file_object.write("This line overwrites previous content!")
file_object.close()

# check after write
file_object = open("mytextfile.txt", "r")
print(file_object.read())
file_object.close()

# write back original content
file_object = open("mytextfile.txt", "w")
file_object.write(original_content)
file_object.close()