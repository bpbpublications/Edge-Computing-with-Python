import sys
import requests

BASE_API_URL = 'http://<IP-Address>:9000'
API_END_POINT = BASE_API_URL + "/exec"
sql_query = "select * from machine"

try:
    response = requests.get(API_END_POINT, params={'query': sql_query}).json()
    for record in response['dataset']:
        print(f"Name={record[0]}, Value={record[1]}, Timestamp={record[2]}")
except requests.exceptions.RequestException as e:
    print(f'Error: {e}', file=sys.stderr)