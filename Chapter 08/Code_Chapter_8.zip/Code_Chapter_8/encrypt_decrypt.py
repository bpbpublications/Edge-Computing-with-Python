from cryptography.fernet import Fernet

message = input("Enter message: ")
key = Fernet.generate_key()
fernet = Fernet(key)
encrypted = fernet.encrypt(message.encode())
decrypted = fernet.decrypt(encrypted).decode()

print("Original message: ", message)
print("After encryption: ", encrypted)
print("After decryption: ", decrypted)