import requests
import os
os.environ["REQUESTS_CA_BUNDLE"] = \
'C:\\Program Files\\Git\\mingw64\\ssl\\certs\\ca-bundle.crt'

BASE_API_URL = "https://localhost:5001/"
API_END_POINT = BASE_API_URL + "persons"

def display_all(message:str):
   print("Displaying all records -> " + message)
   response = requests.get(API_END_POINT, cert=('cert.pem', 'key.pem'))
   print(f"{response.json()}\n==========================================")
   return

def add_new_record(name:str, age:int, salary:float):
   print("Add new record")
   record_to_add = {"NAME": name, "AGE": age, "SALARY": salary}
   response = requests.post(API_END_POINT, json=record_to_add, cert=('cert.pem', 'key.pem'))
   print(f"{response.json()}\n==========================================")
   return

def update_record(id:int, field:str, value):
   print("Update the record")
   record_to_update = {"ID": id, "FIELD":field, "VALUE":value}
   response = requests.patch(API_END_POINT, json=record_to_update, cert=('cert.pem', 'key.pem'))
   print(f"{response.json()}\n==========================================")
   return

def delete_record(id:int):
   print("Delete the record")
   record_to_delete = {"ID": id}
   response = requests.delete(API_END_POINT, json=record_to_delete, cert=('cert.pem', 'key.pem'))
   print(f"{response.json()}\n==========================================")
   return

if __name__ == "__main__":
   display_all("Initial position")
   add_new_record("Harry", 30, 20000)
   update_record(1, "SALARY", 20500)
   display_all("After updating the record")
   delete_record(1)
   display_all("After deleting record")