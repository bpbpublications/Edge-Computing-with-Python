from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

conn = sqlite3.connect('my_database.db', check_same_thread=False)
print("Opened database successfully")

conn.execute("CREATE TABLE IF NOT EXISTS Person \
   (ID INT PRIMARY KEY NOT NULL, NAME TEXT NOT NULL, AGE INT, SALARY REAL)")
print("Table opened successfully")

def get_new_id():
   new_id = 0
   cursor = conn.execute("SELECT MAX(ID) from Person")
   for row in cursor:
      max_val = row[0]
      if max_val == None:
         return 1
      new_id = int(row[0]) + 1
      return new_id

@app.get("/persons")
def select_persons():
   persons = []
   try:
      cursor = conn.execute("SELECT * from Person")
      all_records = cursor.fetchall()
      if all_records.__len__() == 0:
         return {"error": "No record(s) found"}, 514
      for row in all_records:
         record = {}
         record["ID"] = row[0]
         record["NAME"] = row[1]
         record["AGE"] = row[2]
         record["SALARY"] = row[3]
         persons.append(record)
      return jsonify(persons)
   except Exception as er:
      return {"error": "Error in Database"}, 515

@app.get("/persons/<id>")
def select_person_id(id):
   persons = []
   try:
      cursor = conn.execute(f"SELECT * from Person WHERE ID = {id}")
      all_records = cursor.fetchall()
      if all_records.__len__() == 0:
         return {"error": "No record(s) found"}, 514
      for row in all_records:
         record = {}
         record["ID"] = row[0]
         record["NAME"] = row[1]
         record["AGE"] = row[2]
         record["SALARY"] = row[3]
         persons.append(record)
         return jsonify(persons)
   except Exception as er:
      return {"error": "Error in Database"}, 515

@app.post("/persons")
def insert_person():
   if request.is_json:
      json_data = dict(request.get_json())
      id = get_new_id()
      if json_data.__contains__('NAME') != True:
         return {"error": "Request does not contain NAME"}, 416      
      name = str(json_data['NAME']).strip()

      if json_data.__contains__('AGE') != True:
         return {"error": "Request does not contain AGE"}, 416      
      age = str(json_data['AGE']).strip()

      if json_data.__contains__('SALARY') != True:
         return {"error": "Request does not contain SALARY"}, 416      
      salary = str(json_data['SALARY']).strip()      
      record = f"{id}, '{name}', {int(age)}, {float(salary)}"
      conn.execute(f"INSERT INTO Person (ID, NAME, AGE, SALARY) \
         VALUES ({record})")
      conn.commit()
      return jsonify("{" + f"Success: {record}" + "}"), 201
   else:
      return {"error": "Request is not JSON"}, 415

@app.patch("/persons")
def update_person():
   if request.is_json:
      json_data = dict(request.get_json())
      if json_data.__contains__('ID') != True:
         return {"error": "Request does not contain ID"}, 416
      id = str(json_data['ID']).strip()
      
      if json_data.__contains__('FIELD') != True:
         return {"error": "Request does not contain FIELD"}, 416
      field_to_update = str(json_data['FIELD']).strip()
      
      if json_data.__contains__('VALUE') != True:
         return {"error": "Request does not contain VALUE"}, 416
      field_value = str(json_data['VALUE']).strip()
      conn.execute(f"UPDATE Person set {field_to_update} = {int(field_value)} \
         where ID = {id}")
      conn.commit()
      return jsonify("{" + f"Success: {field_to_update} = {int(field_value)} \
         for ID = {id}" + "}"), 201
   else:
      return {"error": "Request is not JSON"}, 415

@app.delete("/persons")
def delete_person():
   if request.is_json:
      json_data = dict(request.get_json())
      if json_data.__contains__('ID') != True:
         return {"error": "Request does not contain ID"}, 416
      id = str(json_data['ID']).strip()
      conn.execute(f"DELETE from Person where ID = {id}")
      conn.commit()
      return jsonify("{" + f"Success: Deleted ID = {id}" + "}"), 201
   else:
      return {"error": "Request is not JSON"}, 415

if __name__ == "__main__":
   app.run(host="0.0.0.0", port=int("5001"), ssl_context=('cert.pem', 'key.pem'))
   conn.close()
