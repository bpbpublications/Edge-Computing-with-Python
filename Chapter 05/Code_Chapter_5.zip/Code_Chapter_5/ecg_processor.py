import neurokit2 as nk
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import serial

matplotlib.interactive(True)
com4_port = serial.Serial(port = "COM4", baudrate=115200, timeout = 10)
ecg_bytes_received = bytes(b'')
ecg_data_list = []
lf_hf_normal_ratio = 2.5

def init_com():
    global com4_port
    com4_port.close()
    com4_port.open()
    return

def close_com():
    global com4_port
    print('Closing communication')
    com4_port.close()
    return

def display_alert():
    plt.figure(1)
    plt.figtext(1/4, 1/2, "ALERT - Abnormal LF/HF Ratio", fontsize=12, color='red')
    return

def ecg_data_acquisition():
    global ecg_bytes_received
    global ecg_data_list
    global com4_port
    
    # Read all the bytes till port is open
    while (com4_port.is_open):
        data_received = com4_port.read(64)
        data_decoded = data_received.decode()
        if data_decoded == '':
            # Stop the communication when stop signal received
            if ecg_bytes_received.__contains__(b'stop'):
                close_com()
                break
            continue
        # Accumulate all the received bytes
        ecg_bytes_received = ecg_bytes_received.__add__(data_received)

    # Each byte is separated by '#', split and make a list
    ecg_data_bytes_list = ecg_bytes_received.split(b'#')
    ecg_data_bytes_list.remove(b'stop')
    
    # Decode each byte, convert to float and make a list
    for ecg_data_bytes in ecg_data_bytes_list:
        ecg_data_value = np.float64(ecg_data_bytes.decode())
        ecg_data_list.append(ecg_data_value)
    return

def process_ecg_data_and_handle_output():
    global ecg_data_list

    # Make DataFrame to Visualize
    ecg_dataframe = pd.DataFrame({"Patient ECG": ecg_data_list})

    # Find R-peaks from ECG data
    peaks, info = nk.ecg_peaks(ecg_data_list, sampling_rate=500)

    ## Heart Rate Variability (HRV) ##

    # Compute and Display Frequency-Domain indices
    hrv_freq = nk.hrv_frequency(peaks, sampling_rate=100, show=True)

    # Compute and Display Time-Domain indices
    hrv_time = nk.hrv_time(peaks, sampling_rate=100, show=True)

    # Plot ECG Signals
    nk.signal_plot(ecg_dataframe, subplots=False)

    # Check for abnormal condition and raise alert
    lf_hf_ratio_current = (hrv_freq['HRV_LFHF']).item()
    if  lf_hf_ratio_current > lf_hf_normal_ratio:
        display_alert()
    return

def main():
    init_com()
    ecg_data_acquisition()
    process_ecg_data_and_handle_output()
    return

if __name__ == "__main__":
    main()
    
    # Just to hold all the plotted views
    plt.waitforbuttonpress()