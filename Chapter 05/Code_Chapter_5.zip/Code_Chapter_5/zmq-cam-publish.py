import zmq
import imutils.video as vidUtil
from PIL import Image
import io

pub_context = zmq.Context()
pub_socket = pub_context.socket(zmq.PUB)
pub_socket.bind("tcp://*:5556")

def pil_image_to_byte_array(image):
    imgByteArr = io.BytesIO()
    image.save(imgByteArr, "PNG")
    return imgByteArr.getvalue()

# define a video capture object
camera = vidUtil.VideoStream(src=0, framerate=32).start()
while(True):	
	# Capture the video frame by frame
    frame = camera.read()
    pil_image = Image.fromarray(frame) # get PIL image from the frame
    byte_array = pil_image_to_byte_array(pil_image) # convert to byte array
    pub_socket.send(byte_array)