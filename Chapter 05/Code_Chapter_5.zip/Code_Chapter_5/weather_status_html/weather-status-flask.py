import json
import sys
from urllib import request, error
from flask import Flask
from flask import request as flaskRequest
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

BASE_API_URL = "http://api.openweathermap.org/data/2.5/weather"

def make_api_url(city_name):
    api_key = 'xxxxxxxXXXXXXXXXXXXXXXXXXXXXXXxxxxx'
    return (f"{BASE_API_URL}?q={city_name}&units=metric&appid={api_key}")

def acquire_weather_data(query_api_url):
    try:
        api_response = request.urlopen(query_api_url)
    except error.HTTPError as http_error:
        sys.exit(f"Error: {http_error.info}")

    weather_data = api_response.read()

    try:
        return json.loads(weather_data)
    except json.JSONDecodeError:
        sys.exit(",Unrecognized server response.")

def proces_and_output_weather_info(weather_data):
    city_name = weather_data["name"]
    weather_description = weather_data["weather"][0]["description"]
    temperature = weather_data["main"]["temp"]
    pressure = weather_data["main"]["pressure"]
    humidity = weather_data["main"]["humidity"]
    return(f"{city_name.capitalize()}&emsp;"
            f"{weather_description.capitalize()}&emsp;({temperature})°C&emsp;"
            f"Pressure={pressure}&emsp;Humidity={humidity}")

@app.route("/getweather", methods=['GET'])
def getdata():
    cityname = flaskRequest.args['city']
    api_query_url = make_api_url(cityname)
    weather_data = acquire_weather_data(api_query_url)
    return proces_and_output_weather_info(weather_data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int("5001"))