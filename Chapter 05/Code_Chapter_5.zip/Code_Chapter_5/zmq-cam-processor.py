import zmq
import cv2
from numpy import asarray
from PIL import Image
import io

sub_context = zmq.Context()
sub_socket = sub_context.socket(zmq.SUB)
sub_socket.connect("tcp://localhost:5556")
sub_socket.subscribe("")

def byte_array_to_pil_image(byte_array):
    return Image.open(io.BytesIO(byte_array))

while True:
    byte_array = sub_socket.recv() # receive bytes from socket
    pil_image = byte_array_to_pil_image(byte_array) # convert bytes to Image
    frame = asarray(pil_image) # get array from Image i.e Frame
    
    # Display the resulting frame
    cv2.imshow('frame', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        cv2.destroyAllWindows()
        break