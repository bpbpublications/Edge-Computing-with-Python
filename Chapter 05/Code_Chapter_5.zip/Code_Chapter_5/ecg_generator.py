import neurokit2 as nk
import serial

ecg_data = nk.ecg_simulate(duration=10, method="ecgsyn")
com3_port = serial.Serial(port = "COM3", baudrate=115200, timeout = 1)
com3_port.close()
com3_port.open()
ecg_bytes_to_send = bytes(b'')

if not com3_port.is_open:
    print('Port not open')
else:
    # make a stream of bytes separated by '#'
    for ecg_val in ecg_data:
        data_encoded = bytes(str(ecg_val), 'utf-8')
        ecg_bytes_to_send = ecg_bytes_to_send.__add__(data_encoded)
        ecg_bytes_to_send = ecg_bytes_to_send.__add__(b'#')

# add stop signal
ecg_bytes_to_send = ecg_bytes_to_send.__add__(b'stop')
com3_port.write(ecg_bytes_to_send)
com3_port.close()