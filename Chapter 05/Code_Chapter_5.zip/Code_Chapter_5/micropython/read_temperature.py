import machine
i2c = machine.I2C(scl=machine.Pin('Y5'), sda=machine.Pin('Y4'))
byte_array = bytearray(2)
i2c.readfrom_mem_into(24, 5, byte_array)
value = byte_array[0] << 8 | byte_array[1]
temp = (value & 0xFFF) / 16.0
if value & 0x1000:
    temp -= 256.0
    print(temp)