import socket
import json

def proces_and_output_weather_info(raw_data:str):
    startIndex = raw_data.find('{')
    data = raw_data[startIndex:len(raw_data)]
    weather_data = json.loads(data)
    city_name = weather_data["name"]
    weather_description = weather_data["weather"][0]["description"]
    temperature = weather_data["main"]["temp"]
    pressure = weather_data["main"]["pressure"]
    humidity = weather_data["main"]["humidity"]
    print(city_name+"\t"+
            weather_description+"\t"+str(temperature)+"°C\t"+
            "Pressure="+str(pressure)+"\tHumidity="+str(humidity))

host='api.openweathermap.org'
path="data/2.5/weather?q=bangalore&units=metric&appid=xxxxxxxXXXXXXXXXXXXXXXXXXXXXXXxxxxx"
addr = socket.getaddrinfo(host, 80)[0][-1]
s = socket.socket()
s.connect(addr)
s.send(bytes('GET /%s HTTP/1.0\r\nHost: %s\r\n\r\n' % (path, host), 'utf8'))
data = s.recv(10240)
if data:
    proces_and_output_weather_info(str(data, 'utf8'))

s.close()
