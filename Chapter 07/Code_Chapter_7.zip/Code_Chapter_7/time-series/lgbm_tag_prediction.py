import pandas as pd
import numpy as np
from lightgbm import LGBMRegressor
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error

ts_dataframe = pd.read_csv("./data/machine_temperature_system_failure.csv")
ts_dataframe['timestamp'] = pd.to_datetime(ts_dataframe['timestamp'])

#set timestamp as index
ts_dataframe = ts_dataframe.set_index(ts_dataframe.timestamp)
ts_dataframe.drop('timestamp', axis=1, inplace=True)

#Get minute, hour, day, month, year, dayofweek from datetime index
ts_dataframe['minute'] = ts_dataframe.index.minute
ts_dataframe['hour'] = ts_dataframe.index.hour
ts_dataframe['day'] = ts_dataframe.index.day
ts_dataframe['month'] = ts_dataframe.index.month
ts_dataframe['year'] = ts_dataframe.index.year
ts_dataframe['dayofweek'] = ts_dataframe.index.dayofweek

X = ts_dataframe.drop('value', axis=1)
y = ts_dataframe['value']

ts_dataframe = ts_dataframe.dropna()
data_size = ts_dataframe.values.__len__()
train_size = int(data_size * 0.8)

X_train, X_test = X.iloc[0:train_size], X.iloc[train_size: ]
y_train, y_test = y.iloc[0:train_size], y.iloc[train_size: ]

model = LGBMRegressor(learning_rate=0.30, max_depth=-50, random_state=42)
model = model.fit(X_train, y_train)
predictions = model.predict(X_test)
print('Training accuracy {:.4f}'.format(model.score(X_train, y_train)))
print('Testing accuracy {:.4f}'.format(model.score(X_test, y_test)))
error = np.round(mean_absolute_error(y_test, predictions), 3)    

#plot reality vs prediction for the last week of the dataset
fig = plt.figure(figsize=(12, 4))
plt.title(f'Real vs Prediction - Mean Absolute Error {error}', fontsize=12)
plt.plot(y_test, color='red')
plt.plot(pd.Series(predictions, index=y_test.index), color='green')
plt.xlabel('Time', fontsize=10)
plt.ylabel('Temperature', fontsize=10)
plt.legend(labels=['Real', 'Prediction'], fontsize=10)
plt.grid()
plt.show()