import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error
from sklearn import preprocessing
from keras.layers.core import Dense, Activation, Dropout
from keras.layers import LSTM
from keras.models import Sequential

ts_dataframe = pd.read_csv("./data/machine_temperature_system_failure.csv")
ts_dataframe['timestamp'] = pd.to_datetime(ts_dataframe['timestamp'])

#set timestamp as index
ts_dataframe = ts_dataframe.set_index(ts_dataframe.timestamp)
ts_dataframe.drop('timestamp', axis=1, inplace=True)

#Get minute, hour, day, month, year, dayofweek from datetime index
ts_dataframe['minute'] = ts_dataframe.index.minute
ts_dataframe['hour'] = ts_dataframe.index.hour
ts_dataframe['day'] = ts_dataframe.index.day
ts_dataframe['month'] = ts_dataframe.index.month
ts_dataframe['year'] = ts_dataframe.index.year
ts_dataframe['dayofweek'] = ts_dataframe.index.dayofweek

X = ts_dataframe[['minute', 'hour', 'day', 'month', 'year', 'dayofweek']]
y = ts_dataframe[['value']]

#Get the data prepared for the model (LSTM)
scaler = preprocessing.StandardScaler()
transformed_dataset = scaler.fit_transform(X)
X = pd.DataFrame(transformed_dataset)
transformed_dataset = scaler.fit_transform(y)
y = pd.DataFrame(transformed_dataset)

dataset_size = X.values.__len__()
train_size = int(dataset_size * 0.8)

# X & y sample training data
sample_X_train = X[0:train_size].values
sample_y_train = y[0:train_size][0].values

# X & y sample test data
sample_X_test = X[train_size:].values
sample_y_test = y[train_size:][0].values

#shape the datasets with 3rd dim as needed by sequential model
def shape_data(dataset, shape_length):
    shaped_data_list = []
    dataset_length = len(dataset)
    for index in range(dataset_length - shape_length):
        shaped_data_list.append(dataset[index: index + shape_length])
    return np.asarray(shaped_data_list)

x_train = shape_data(sample_X_train, 100)
x_test  = shape_data(sample_X_test, 100)
y_train = sample_y_train[-x_train.shape[0]:]
y_test  = sample_y_test[-x_test.shape[0]:]

#Create the model
model = Sequential()
model.add(LSTM(50, return_sequences=True))
model.add(Dropout(0.2))
model.add(LSTM(100, return_sequences=False))
model.add(Dropout(0.2))
model.add(Dense(units=1))
model.add(Activation('linear'))
model.compile(loss='mse')

#Train the model
model.fit(x_train, y_train, epochs=5, batch_size=64)

#Execute the model
predictions = model.predict(x_test)
error = np.round(mean_absolute_error(y_test, predictions), 3)

#plot reality vs prediction
fig = plt.figure(figsize=(12, 4))
plt.title(f'Real vs Prediction - Mean Absolute Error {error}', fontsize=12)
plt.plot(y_test, color='red')
plt.plot(predictions, color='green')
plt.legend(labels=['Real', 'Prediction'], fontsize=10)
plt.grid()
plt.show()