import json
import numpy
import argparse
from PIL import Image
from keras.models import load_model

ts_model = load_model('traffic_sign_trained_model.h5')

def get_config_json():
    file_object = open("traffic_sign_config.json", "r")
    file_content = file_object.read()
    file_object.close()
    return json.loads(file_content)

def read_args():
    parser = argparse.ArgumentParser(
        description="Identify the traffic-sign using CNN model"
    )
    parser.add_argument(
        "file", type=str, help="input image file with complete path"
    )
    return parser.parse_args()

def identify_category(image_file: str):
    image_data = Image.open(image_file)
    image_data = image_data.resize((30,30))
    image_data = numpy.expand_dims(image_data, axis=0)
    image_data = numpy.array(image_data)
    prediction = ts_model.predict([image_data])[0]
    category = numpy.argmax(prediction, axis=0)
    return str(category)

if __name__ == "__main__":
    category_json = get_config_json()
    args = read_args()
    category = identify_category(args.file)
    print(f"Category: {category} \n Meaning: {category_json[category]}")
