import os
import numpy as np 
import pandas as pd 
from PIL import Image
from keras.models import Sequential
from keras.utils import to_categorical
from sklearn.metrics import accuracy_score
from keras.layers import Conv2D, MaxPool2D, Dense, Flatten, Dropout

images_data_list = []
dataset_path = os.path.join(os.getcwd(), 'data')

train_meta = pd.read_csv(os.path.join(dataset_path, 'Train.csv'))
used_categories_list = train_meta["ClassId"].values.tolist()
image_files_list = train_meta["Path"].values

dataset_meta = pd.read_csv(os.path.join(dataset_path, 'Meta.csv'))
total_categories = dataset_meta["ClassId"].values.size

for image_file in image_files_list:
    try:
        image_data = Image.open(os.path.join(dataset_path, image_file))
        image_data = image_data.resize((30, 30))
        image_data = np.array(image_data)
        images_data_list.append(image_data)
    except:
        print("Image loading failed!")

#Converting lists into numpy arrays
X_train = np.array(images_data_list)
y_train = np.array(used_categories_list)

#Converting to binay encoding
y_train = to_categorical(y_train, total_categories)

#Building the model
ts_model = Sequential()
ts_model.add(Conv2D(filters=32, kernel_size=(5,5), activation='relu', 
                input_shape=X_train.shape[1:]))
ts_model.add(Conv2D(filters=32, kernel_size=(5,5), activation='relu'))
ts_model.add(MaxPool2D(pool_size=(2, 2)))
ts_model.add(Dropout(rate=0.25))
ts_model.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))
ts_model.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))
ts_model.add(MaxPool2D(pool_size=(2, 2)))
ts_model.add(Dropout(rate=0.25))
ts_model.add(Flatten())
ts_model.add(Dense(256, activation='relu'))
ts_model.add(Dropout(rate=0.5))
ts_model.add(Dense(43, activation='softmax'))

#Configure the model for training
ts_model.compile(
    loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

iterations = 15
#Train the model
training_history = ts_model.fit(
    X_train, y_train, batch_size=32, epochs=iterations)

#testing accuracy on test dataset
test_meta = pd.read_csv(os.path.join(dataset_path,'Test.csv'))
used_categories_list = test_meta["ClassId"].values
image_files_list = test_meta["Path"].values
images_data_list = []
for image_file in image_files_list:
    try:
        image_data = Image.open(os.path.join(dataset_path, image_file))
        image_data = image_data.resize((30, 30))
        image_data = np.array(image_data)
        images_data_list.append(image_data)
    except:
        print("Image loading failed!")

X_test = np.array(images_data_list)
y_test = np.array(used_categories_list)

#Converting from binary encoding to sigle-digit vector
predictions = np.argmax(ts_model.predict(X_test), axis=1)

#Accuracy with the test data
print(accuracy_score(y_test, predictions))
ts_model.save("traffic_sign_trained_model.h5")
