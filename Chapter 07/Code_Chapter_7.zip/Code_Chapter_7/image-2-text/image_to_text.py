from PIL import Image
from pytesseract import pytesseract

base_path = './data/'
pytesseract.tesseract_cmd = "C:/Program Files/Tesseract-OCR/tesseract.exe"

for i in range(3):
    image_path = base_path + str(i) + '.png'
    image = Image.open(image_path)
    image_text = pytesseract.image_to_string(image, lang="eng")
    print(image_text)