import json
import time
import random
from paho.mqtt import client as mqtt

MQTT_BROKER = "192.168.1.10"
MQTT_PORT = 1883
TAGS = ["unit1-temp", "unit1-press", "unit2-temp", "unit2-press"]
MQTT_TOPIC_MAP = {"unit1-temp":"factory/unit1/machine/temperature",
                "unit1-press":"factory/unit1/machine/pressure",
                "unit2-temp":"factory/unit2/machine/temperature",
                "unit2-press":"factory/unit2/machine/pressure"}

def get_mqtt_client():
    """Return the MQTT client object."""
    client = mqtt.Client()
    client.connected_flag = False
    client.on_connect = on_connect
    client.on_publish = on_publish
    return client

def on_connect(client, userdata, flags, rc):
    print(f"CONNACK received with code {rc}")
    if rc == 0:
        print("connected to MQTT broker")
        client.connected_flag = True  # set flag
    else:
        print(f"Error connecting broker, returned code = {rc}")

def on_publish(client, userdata, mid):
    print("Published message ID: " + str(mid))

client = get_mqtt_client()
status = client.connect(MQTT_BROKER, port=MQTT_PORT)
time.sleep(5)  # Wait for connection setup to complete
client.loop_start()
while(True):
    tag_index = random.randint(0, 3)
    tag = TAGS[tag_index]
    value = random.randint(50, 100)
    topic_payload = {"tag":tag, "value":value}
    client.publish(MQTT_TOPIC_MAP[tag], json.dumps(topic_payload), qos=1)
    time.sleep(1)