import time
from paho.mqtt import client as mqtt

MQTT_BROKER = "192.168.1.10"
MQTT_PORT = 1883
MQTT_TOPIC = "factory/#"

def get_mqtt_client():
    """Return the MQTT client object."""
    client = mqtt.Client()
    client.connected_flag = False
    client.on_connect = on_connect
    client.on_message = on_message
    return client

def on_connect(client, userdata, flags, rc):
    print(f"CONNACK received with code {rc}")
    if rc == 0:
        print("connected to MQTT broker")
        client.connected_flag = True  # set flag
    else:
        print(f"Error connecting broker, returned code = {rc}")

def on_message(client, userdata, msg):
    print(f"Received message = {msg.payload} On topic = {msg.topic}")

client = get_mqtt_client()
client.on_message = on_message
client.connect(MQTT_BROKER, port=MQTT_PORT)
client.subscribe(MQTT_TOPIC)
time.sleep(5)  # Wait for connection setup to complete
client.loop_forever()