from flask import Flask, request
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

BASE_API_URL = "http://192.168.1.10:1026/v2/"
API_END_POINT = BASE_API_URL + "subscriptions"

response_json = requests.get(API_END_POINT).json()
if response_json.__len__() == 0:
   subs_json = {"description": "subscription", "subject": \
   {"entities": [{"id": "Motor1", "type": "Motor"}],  \
   "condition": {"attrs": ["temperature"]}}, "notification": \
   {"http": {"url": "http://sub-host:1028/tempnotice"}, \
   "attrs": ["temperature"]}}
   resp = requests.post(API_END_POINT, json=subs_json)
   print(f"subscription status = {resp.status_code}")

@app.post("/tempnotice")
def temp_notice():
   if request.is_json:
      json_data = dict(request.get_json())
      response = f"notice received = {json_data}"
      print(response)
      return response, 200

if __name__ == "__main__":
   app.run(host="0.0.0.0", port=int("1028"))