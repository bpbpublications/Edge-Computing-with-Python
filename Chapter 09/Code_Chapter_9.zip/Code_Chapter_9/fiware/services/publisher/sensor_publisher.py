import random
from time import sleep
import requests
import logging

BASE_API_URL = "http://192.168.1.10:1026/v2/"
API_END_POINT = BASE_API_URL + "entities"
UPDATE_URL = API_END_POINT + "/Motor1/attrs/temperature"

response_json = requests.get(API_END_POINT).json()
if response_json.__len__() == 0:
    record_to_add = {"id":"Motor1","type":"Motor","temperature": 
                    {"value": 30,"type": "Number"},"rpm": 
                    {"value": 500,"type":"Number"}}
    requests.post(API_END_POINT, json=record_to_add)

while True:
    temperature = random.randint(25, 30)
    json_data = {"value":temperature, "type":"Number"}
    response = requests.put(UPDATE_URL, json=json_data)
    sleep(1)
    logging.info(f"publish status = {response.status_code}")
    #print(f"publish status = {response.status_code}")