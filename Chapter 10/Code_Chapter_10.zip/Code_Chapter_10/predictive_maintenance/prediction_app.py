import time
import pandas
import json
import numpy as np
import threading
from flask import Flask, render_template
from flask_cors import CORS
from flask_socketio import SocketIO
from keras.models import load_model
from paho.mqtt import client as mqtt

app = Flask(__name__)
socketio = SocketIO(app)
CORS(app)

model = load_model('./pump_LSTM_1.h5')
MQTT_BROKER = "mqtt-broker"
MQTT_PORT = 1883
MQTT_TOPIC = "/data/sensor/#"
TIME_PREDICTED = 0

def do_prediction(data_x:pandas.DataFrame, data_y:pandas.DataFrame):
    # inference
    [yhat, yclass] = model.predict(data_x)
    y_class = [np.argmax(yclass[i], axis=0) for i in range(len(yclass))]

    # calculate in how much time the failure happens
    # find the index of the first time failure
    first_broken_tested = np.where(data_y == 0)[0]
    # find the index of the first time recovery
    first_recover_predicted = y_class.index(2)
    TIME_PREDICTED = (first_broken_tested[0] - first_recover_predicted) / 60
    return TIME_PREDICTED

def get_mqtt_client():
    """Return the MQTT client object."""
    client = mqtt.Client()
    client.connected_flag = False
    client.on_connect = on_connect
    client.on_message = on_message
    return client

def on_connect(client, userdata, flags, rc):
    print(f"CONNACK received with code {rc}")
    if rc == 0:
        print("connected to MQTT broker")
        client.connected_flag = True  # set flag
    else:
        print(f"Error connecting broker, returned code = {rc}")

def on_message(client, userdata, msg):
    print(f"Data received")
    payload_json= json.loads(msg.payload)
    data_x = payload_json['data_x']
    data_y = payload_json['data_y']
    x_shape = payload_json['x_shape']
    y_shape = payload_json['y_shape']
    data_x = np.reshape(data_x, newshape=x_shape)
    data_y = np.reshape(data_y, newshape=y_shape)
    do_prediction(data_x, data_y)
    socketio.emit('prediction done')

@app.get("/")
def handle_get():
    global TIME_PREDICTED
    return render_template('index.html', message=TIME_PREDICTED, 
    async_mode=socketio.async_mode)

@socketio.on('html event')
def handle_connect(data):
    print(data)

def mqtt_thread_func():
    client = get_mqtt_client()
    client.connect(MQTT_BROKER, port=MQTT_PORT)
    client.subscribe(MQTT_TOPIC)
    time.sleep(5)  # Wait for connection setup to complete
    client.loop_forever()

if __name__ == "__main__":
    time.sleep(5)
    x = threading.Thread(target=mqtt_thread_func)
    x.start()
    socketio.run(app, host="0.0.0.0", port=int("1028"))