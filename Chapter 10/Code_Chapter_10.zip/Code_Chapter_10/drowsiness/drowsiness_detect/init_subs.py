import requests
import time

BASE_API_URL = "http://orion-broker:1026/v2/"
API_END_POINT = BASE_API_URL + "subscriptions"

def add_subscription():
    subs_json = {"description": "Notify for ECG Update", "subject": \
    {"entities": [{"id": "drv:ecg", "type": "Driver"}],  \
    "condition": {"attrs": ["ecg"]}}, "notification": \
    {"http": {"url": "http://drowsiness-app:1028/ecg_process"}, \
    "attrs": ["driver-id", "ecg"]}}
    resp = requests.post(API_END_POINT, json=subs_json)
    print(f"subscription status = {resp.status_code}")
    return

def init_subscription():
    time.sleep(5)
    response_json = requests.get(API_END_POINT).json()
    if response_json.__len__() == 0:
        add_subscription()
        return
    
    for json_item in response_json:
        if json_item["subject"]["entities"][0]["type"] == "Driver":
            return
    add_subscription()
    return
