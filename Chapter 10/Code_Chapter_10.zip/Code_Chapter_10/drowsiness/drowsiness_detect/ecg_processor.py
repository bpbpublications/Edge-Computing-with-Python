import neurokit2 as nk
import requests
from flask import Flask, request
from flask_cors import CORS
from init_subs import init_subscription
from init_contxt import init_contxt

app = Flask(__name__)
CORS(app)

BASE_API_URL = "http://orion-broker:1026/v2/"
API_END_POINT = BASE_API_URL + "entities"
UPDATE_RESULT_URL = API_END_POINT + "/ecg:result/attrs"
LFHF_NORMAL = 3.0
LFHF_ABNORMAL = 4.0

def do_process_ecg(ecg_data_dict:dict):
    id_json = ecg_data_dict.get("driver-id")
    id = id_json.get("value")
    ecg_data_json = ecg_data_dict.get("ecg")
    ecg_data = ecg_data_json.get("value")
    response_state = {"id": id, "state": "Normal"}
    if id == None or ecg_data == None:
        response_state["state"] = "Data Error"
        return response_state, 400
    try:
        peaks, info = nk.ecg_peaks(ecg_data, sampling_rate=100)
        hrv_freq = nk.hrv_frequency(peaks, sampling_rate=100, show=False)
        lf_hf_ratio_current = (hrv_freq['HRV_LFHF']).item()
        if lf_hf_ratio_current <= LFHF_NORMAL:
            return response_state, 200
        if lf_hf_ratio_current > LFHF_NORMAL and lf_hf_ratio_current <= LFHF_ABNORMAL:
            response_state["state"] = "Fatigued"
            return response_state, 200
        if lf_hf_ratio_current > LFHF_ABNORMAL:
            response_state["state"] = "Drowsy"
            return response_state, 200
    except Exception as ex:    
        response_state["state"] = "Undefined"
        return response_state, 500

def do_update_result(ecg_state_result:dict):
    id = ecg_state_result["id"]
    state = ecg_state_result["state"]
    ecg_result_dict = {"driver-id": {"value": id, "type": "Text"},
        "state": {"value": state, "type": "Text"}}
    response = requests.patch(UPDATE_RESULT_URL, json=ecg_result_dict)
    print(f"ecg result update status = {response.status_code}")
    return

@app.post("/ecg_process")
def ecg_process():
    if request.is_json:
        ecg_json_obj = dict(request.get_json())
        ecg_data_dict = ecg_json_obj["data"][0]
        ecg_state_result, code = do_process_ecg(ecg_data_dict)
        do_update_result(ecg_state_result)
        return ecg_state_result, code

if __name__ == "__main__":
    init_contxt()
    init_subscription()
    app.run(host="0.0.0.0", port=int("1028"))