import requests
import time

BASE_API_URL = "http://orion-broker:1026/v2/"
API_END_POINT = BASE_API_URL + "entities"
GET_ECG_END_POINT = API_END_POINT + "/drv:ecg"
GET_RESULT_END_POINT = API_END_POINT + "/ecg:result"

def add_ecg_context():
    context_json = {"id": "drv:ecg", "type": "Driver", 
    "driver-id": {"value": "DRIVER_1", "type": "Text"}, 
    "ecg": {"value": [], "type": "List"}}
    resp = requests.post(API_END_POINT, json=context_json)
    print(f"ecg context init status = {resp.status_code}")
    return

def add_result_context():
    result_json = {"id": "ecg:result", "type": "Result", 
    "driver-id": {"value": "DRIVER_1", "type": "Text"},
    "state": {"value": "Undefined", "type": "Text"}}
    resp = requests.post(API_END_POINT, json=result_json)
    print(f"ecg result init status = {resp.status_code}")
    return

def init_contxt():
    time.sleep(5)
    response_json = requests.get(GET_ECG_END_POINT).json()
    if response_json.get('error') == 'NotFound':
        add_ecg_context()

    response_json = requests.get(GET_RESULT_END_POINT).json()
    if response_json.get('error') == 'NotFound':
        add_result_context()
    return
