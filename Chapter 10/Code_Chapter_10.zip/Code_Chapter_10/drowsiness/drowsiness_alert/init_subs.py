import requests
import time

BASE_API_URL = "http://192.168.1.10:1026/v2/"
API_END_POINT = BASE_API_URL + "subscriptions"

def add_subscription():
    subs_json = {"description": "Notify for ECG State", "subject": \
    {"entities": [{"id": "ecg:result", "type": "Result"}],  \
    "condition": {"attrs": ["state"]}}, "notification": \
    {"http": {"url": "http://192.168.1.10:1029/"}, \
    "attrs": ["driver-id", "state"]}}
    resp = requests.post(API_END_POINT, json=subs_json)
    print(f"subscription status = {resp.status_code}")
    return

def init_subscription():
    time.sleep(5)
    response_json = requests.get(API_END_POINT).json()
    if response_json.__len__() == 0:
        add_subscription()
        return
    
    for json_item in response_json:
        if json_item["subject"]["entities"][0]["type"] == "Result":
            return
    add_subscription()
    return
