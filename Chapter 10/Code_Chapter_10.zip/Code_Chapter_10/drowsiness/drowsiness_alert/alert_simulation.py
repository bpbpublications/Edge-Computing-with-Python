from flask import Flask, request, render_template
from flask_cors import CORS
from flask_socketio import SocketIO
from init_subs import init_subscription

app = Flask(__name__)
socketio = SocketIO(app)
CORS(app)
driver_state = "Waiting ..."

@app.get("/")
def handle_get():
    global driver_state
    return render_template('index.html', message=driver_state, async_mode=socketio.async_mode)

@app.post("/")
def handle_notice():
    if request.is_json:
        global driver_state
        state_json_obj = dict(request.get_json())
        state_data_dict = state_json_obj["data"][0]
        id_json = state_data_dict.get("driver-id")
        id = id_json.get("value")
        state_json = state_data_dict.get("state")
        state = state_json.get("value")
        driver_state = f"{id} is in {state} state."
        socketio.emit('ecg updated')
        return driver_state, 200

@socketio.on('html event')
def handle_connect(data):
    print(data)

if __name__ == "__main__":
    init_subscription()
    socketio.run(app, host="0.0.0.0", port=int("1029"))