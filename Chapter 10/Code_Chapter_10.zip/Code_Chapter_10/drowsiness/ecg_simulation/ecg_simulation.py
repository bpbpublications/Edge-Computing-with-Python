import pandas as pd
import requests
import time

BASE_API_URL = "http://192.168.1.10:1026/v2/"
API_END_POINT = BASE_API_URL + "entities"
UPDATE_ECG_URL = API_END_POINT + "/drv:ecg/attrs"

ecg_dataframe = pd.read_csv('./ecg_dataset/ptbdb_abnormal.csv')
for col in range(ecg_dataframe.shape[1]):
    ecg_data = ecg_dataframe[ecg_dataframe.columns[col]].drop_duplicates()
    ecg_data_dict = {"driver-id": {"value": "DRIVER_1", "type": "Text"},
    "ecg": {"value": ecg_data.to_list(), "type": "List"}}
    response = requests.patch(UPDATE_ECG_URL, json=ecg_data_dict)
    print(f"ecg update status = {response.status_code}")
    time.sleep(2)
